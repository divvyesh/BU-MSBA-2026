# Big-Data-Analytics-Project-on-Google-Trends-Spikes-to-Signals
This project analyzes global Google Trends spikes to determine if they are random or structured by country environments. Findings reveal a structural divide: emerging markets show volatile, burst-driven spikes, while mature economies exhibit stable, diffuse attention.

# From Spikes to Signals  
### Country-Level Diagnostics of Google Trends Terms

This repository contains the full workflow and analysis for **“From Spikes to Signals”**, a country-level diagnostic of global Google Trends search behavior. The project takes raw trend spikes from Google’s *Rising* and *Top* term lists and turns them into **structural, country-level signals** using PySpark, World Bank indicators, and predictive modeling.

---

## 1. Project Overview

Organizations rely on Google Trends to sense what the world cares about in real time. However:

- It is not obvious **how often** Google refreshes trend lists or how aggressively it replaces terms.
- We rarely know **which trending topics persist**, which disappear, and **which are spam**.
- Dashboards usually treat trend lists as context free, ignoring **country structure** such as GDP, internet access, and governance quality.

This project builds a **big data analytics pipeline** that answers:

1. How does Google refresh *Rising* and *Top* lists over time at global scale  
2. Which trends **survive** versus disappear between refreshes  
3. Which terms **spread across borders** and become global hits, and which are **coordinated spam attacks**  
4. How the **topic mix** of search interest varies by region  
5. How **country structural indicators** relate to search intensity and volatility  
6. Whether we can **predict trend survival** using both trend metrics and macro variables

The end state is a reusable framework that treats Google Trends not as a noisy curiosity, but as a **country-level signal system** that can be tied to real macro conditions.

---

## 2. Data Sources

### 2.1 Google Trends Search Data

We use two international tables exported from the Google Trends BigQuery public dataset (via GCS Parquet):

- **Rising terms** (`international_top_rising_term_*`)
  - ~**33,500** rows after cleaning  
  - Columns include `country_name`, `refresh_date`, `week`, `term`, `rank`, `percent_gain`, `score`

- **Top terms** (`international_top_term_*`)
  - Full history: ~**22,045,302** rows  
  - Compressed “latest snapshot” table: **49,315** rows after de-duplication  
  - Same core schema as rising terms, using `score` instead of `percent_gain`

Across both tables, the project works with **31,184 unique terms** after cleaning.

### 2.2 World Bank Development Indicators

External context comes from a curated subset of the **World Development Indicators** dataset, loaded via a custom Spark schema:

Examples of indicators:

- Economic: `GDP_current_US`, `gdp_per_capita`, `trade_in_services%`
- Connectivity: `individuals_using_internet%`, `access_to_electricity%`, `electric_power_consumption`
- Governance: `control_of_corruption_estimate`, `goverment_effectiveness_estimate`, `voice_and_accountability_estimate`
- Social and risk: `intentional_homicides`, `CO2_emissions`, `renewvable_energy_consumption%`, `avg_precipitation`

World Bank data is joined at the **country-year** level to trend metrics to support country diagnostics and modeling.

---

## 3. Technical Stack and Architecture

**Core technologies**

- **PySpark** for scalable ETL and feature engineering on tens of millions of rows
- **Spark SQL and Window functions** for temporal and country-level analytics
- **Pandas / NumPy** for lightweight aggregations and export
- **Matplotlib, Seaborn, Plotly** for static and interactive visualizations
- **WordCloud** for term-level visual summaries
- **Scikit-learn + PySpark ML** for ROC computation and logistic models
- **Google Cloud Storage (GCS)** for Parquet and CSV data storage

**High level pipeline**

```text
Google Trends & World Bank
        ↓  (exports to GCS: Parquet / CSV)
Spark ingestion layer
        ↓
Standardization & cleaning
        ↓
Feature engineering
  - Term survival
  - Cross-country diffusion
  - Topic categories
  - Country structural metrics
        ↓
Exploratory analysis
  - Temporal panels
  - Choropleths & bar charts
  - Topic mix by region
  - Correlation heatmaps
        ↓
Predictive modeling
  - Logistic regression for term survival
        ↓
Insights & reporting
  - Country archetypes
  - Structural drivers of search behavior
